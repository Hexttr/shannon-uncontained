# API Documentation

> Discovered endpoints for https://tcell.tj

## Summary

| Method | Count |
|--------|-------|
| GET | 108 |
| POST | 123 |
| PUT | 0 |
| DELETE | 0 |
| PATCH | 0 |

---

## GET Endpoints

### `GET /`

**Confidence**: 50%

---

### `GET /%0A`

**Confidence**: 50%

---

### `GET /4g/`

**Confidence**: 50%

---

### `GET /4g/4g-internet/video-portals.php`

**Confidence**: 50%

---

### `GET /_next/static/chunks/1356-39a1ee472b5b9f8d.js`

**Confidence**: 50%

---

### `GET /_next/static/chunks/5945-b91fff362bfd7bf2.js`

**Confidence**: 50%

---

### `GET /_next/static/chunks/app/%5Blocale%5D/page-17915ddc4d15b564.js`

**Confidence**: 50%

---

### `GET /_next/static/css/7356b2e5e72b210e.css`

**Confidence**: 50%

---

### `GET /about-tcell/contacts.php`

**Confidence**: 50%

---

### `GET /assets/images/favicon-web-32.png`

**Confidence**: 50%

---

### `GET /assets/img/gif/people.gif`

**Confidence**: 50%

---

### `GET /assets/vendor/linear-icons/css/linear-icons.min.css`

**Confidence**: 50%

---

### `GET /assets/vendor/simple-line-icons/fonts/Simple-Line-Icons.eot`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| v | query | string |

---

### `GET /bitrix/cache/css/s1/tcell-ru/page_4f70fa7b58ef114b4799dbdc0818e63c/page_4f70fa7b58ef114b4799dbdc0818e63c.css`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| 159683212932574 | query | string |

---

### `GET /bitrix/css/api.core/images/form/checkbox.png`

**Confidence**: 50%

---

### `GET /bitrix/js/api.core/form.js`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| 15131678401760 | query | string |

---

### `GET /bitrix/templates/.default/components/bitrix/breadcrumb/breadcrumb/style.css`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| 1429703193947 | query | string |

---

### `GET /bitrix/templates/tcell-en-corporations/tsr-fonts/ts-icons-all.ttf`

**Confidence**: 50%

---

### `GET /bitrix/templates/tcell-ru/components/askaron/askaron.ibvote.iblock.vote/TCELL_VOTE/images/over.gif`

**Confidence**: 50%

---

### `GET /bitrix/templates/tcell-ru/js/html5shiv-printshiv.min.js`

**Confidence**: 50%

---

### `GET /bitrix/templates/tcell-ru/js/main_rwd_h.min.js`

**Confidence**: 50%

---

### `GET /bitrix/templates/tcell-ru/js/modernizr.custom.js`

**Confidence**: 50%

---

### `GET /bitrix/templates/tcell-tj/images/favicons/apple-touch-icon-144x144.png`

**Confidence**: 50%

---

### `GET /career/vacancies.php`

**Confidence**: 50%

---

### `GET /contact-us/t-solution/chat-bot`

**Confidence**: 50%

---

### `GET /content/videos`

**Confidence**: 50%

---

### `GET /corporations/communication-with-client/corporate-ringtone.php`

**Confidence**: 50%

---

### `GET /corporations/novosti/6306/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| novosti_id | path | integer |

---

### `GET /corporations/roaming/pozvoni-domoi/iz-kitaya.php`

**Confidence**: 50%

---

### `GET /corporations/roaming/real-easy/connection-conditions.php`

**Confidence**: 50%

---

### `GET /corporations/support/services/www.tcell.tj`

**Confidence**: 50%

---

### `GET /en/corporations/services/mobile-payments/top-up-from-agroinvestbank.php`

**Confidence**: 50%

---

### `GET /en/index/index/pageId/1447/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /en/index/index/pageId/2297/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /en/index/index/pageId/516/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /en/links/subscribers/beware-of-scammers/fraud-schemes.php`

**Confidence**: 50%

---

### `GET /en/private-individuals/mobile-connection/565`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| categoryId | query | integer |
| mobile-connection_id | path | integer |

---

### `GET /en/private-individuals/vacancies/3`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| vacancies_id | path | integer |

---

### `GET /en/rates/shares/annual-package-2021.php`

**Confidence**: 50%

---

### `GET /en/roaming/how-to-save/call-back-from-china.php`

**Confidence**: 50%

---

### `GET /en/service/Content-services/igame-2048.php`

**Confidence**: 50%

---

### `GET /en/services/communication/international-communication.php`

**Confidence**: 50%

---

### `GET /en/services/mobile-payments/refilling-the-balance-in-russia.php`

**Confidence**: 50%

---

### `GET /en/t-solution/7`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| t-solution_id | path | integer |

---

### `GET /en/tariffs/unlimited-4g.php`

**Confidence**: 50%

---

### `GET /images/darkoreco.jpg`

**Confidence**: 50%

---

### `GET /internet/mobile-apps/`

**Confidence**: 50%

---

### `GET /mobile-internet/archive/unlim2.php`

**Confidence**: 50%

---

### `GET /public/userfiles/design/online_consultant_5.jpg`

**Confidence**: 50%

---

### `GET /roaming/how-to-save/roaming-from-germany-to-tajikistan.php`

**Confidence**: 50%

---

### `GET /ru/index/index/pageId/1488/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /ru/index/index/pageId/2103/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /ru/index/index/pageId/280/page/4/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |
| page_id | path | integer |

---

### `GET /ru/posts/29`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| posts_id | path | integer |

---

### `GET /ru/private-individuals/services/1326`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| services_id | path | integer |

---

### `GET /services/alif-payments/img/vigoda.svg`

**Confidence**: 50%

---

### `GET /sms`

**Confidence**: 50%

---

### `GET /tg/index/index/pageId/608/`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| pageId_id | path | integer |

---

### `GET /tj/corporations/`

**Confidence**: 50%

---

### `GET /tj/corporations/roaming/ba-hona-zang-bizan/az-olmon.php`

**Confidence**: 50%

---

### `GET /tj/device/3g-modems/`

**Confidence**: 50%

---

### `GET /tj/links/about-tcell/haridori.php`

**Confidence**: 50%

---

### `GET /tj/service/communication/bemahdud10.php`

**Confidence**: 50%

---

### `GET /tj/tarofahoi-nav/tarofai-fason.php`

**Confidence**: 50%

---

### `GET /upload/iblock/39c/aktsii_dubai2018_ru.png`

**Confidence**: 50%

---

### `GET /upload/iblock/943/main_cover_site_01.png`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| iblock_id | path | integer |

---

### `GET /upload/iblock/efc/main_cover_site.png`

**Confidence**: 50%

---

### `GET /upload/medialibrary/22c/1.JPG`

**Confidence**: 50%

---

### `GET /upload/medialibrary/4bf/devices_fb.jpg`

**Confidence**: 50%

---

### `GET /upload/medialibrary/74c/180.png`

**Confidence**: 50%

---

### `GET /upload/medialibrary/9e4/50.jpeg`

**Confidence**: 50%

---

### `GET /upload/medialibrary/d32/1.jpeg`

**Confidence**: 50%

---

### `GET /upload/svg/icon-006.svg`

**Confidence**: 50%

---

### `GET /controllers/ajax/ajax.php`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| q | query | string |

---

### `GET /player.php`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| video | query | string |

---

### `GET /oferta.pdf`

**Confidence**: 50%

---

### `GET /ext-2.0.1/resources/images/default/toolbar/btn-arrow-light.gif`

**Confidence**: 50%

---

### `GET /fonts/SFProDisplay-Semibold.eot`

**Confidence**: 50%

---

### `GET /images/cache/253f0a7025890f78f1de98784e9d9479.png`

**Confidence**: 50%

---

### `GET /images/cache/bd8c40292635f8859c8064b0c9db2093.png`

**Confidence**: 50%

---

### `GET /browserconfig.xml`

**Confidence**: 50%

---

### `GET /assets/index-BpwXjTbW.js`

**Confidence**: 50%

---

### `GET /media/dashboard/20250218045955_9328919.png`

**Confidence**: 50%

---

### `GET /media/dashboard/20250815043437_d18e506576f647a49e023f9044a801ea.png`

**Confidence**: 50%

---

### `GET /Analytics/1254`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| Analytics_id | path | integer |

---

### `GET /en/Card/Index/1254`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| Index_id | path | integer |

---

### `GET /ru/Card/Index/1082`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| Index_id | path | integer |

---

### `GET /Themes/Tcell/Content/scripts/spin.js`

**Confidence**: 50%

---

### `GET /artist/2421`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| artist_id | path | integer |

---

### `GET /artist/43984`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| artist_id | path | integer |

---

### `GET /artist/63183`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| artist_id | path | integer |

---

### `GET /banner/melody/380/263387.png`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| melody_id | path | integer |

---

### `GET /category/427/name/Z`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/428/name/B`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/429/name/X`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/430/popular`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/474/name/%D0%95`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/476/author/Q`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /category/497/name/O`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| category_id | path | integer |

---

### `GET /private/playlist`

**Confidence**: 50%

---

### `GET /user/js/js12530.js`

**Confidence**: 50%

---

### `GET /flags/1x1/km.svg`

**Confidence**: 50%

---

### `GET /flags/4x3/fi.svg`

**Confidence**: 50%

---

### `GET /js/ca.js`

**Confidence**: 50%

---

### `GET /css/icons/volume_high.svg`

**Confidence**: 50%

---

### `GET /tv/img/222x333/21350.jpg`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| img_id | path | string |

---

### `GET /tv/img/222x333/41773.jpg`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| img_id | path | string |

---

### `GET /subscribe/lp3/affimob`

**Confidence**: 50%

---

## POST Endpoints

### `POST /bitrix/cache/css/s1/tcell-ru-new/page_71831cb363645c0bcd5a2686b229e7e6/page_71831cb363645c0bcd5a2686b229e7e6.css`

**Confidence**: 50%

---

### `POST /bitrix/cache/css/s2/tcell-tj-new/page_ac21a55ba5dd10fede41dde80a5535a0/page_ac21a55ba5dd10fede41dde80a5535a0.css`

**Confidence**: 50%

---

### `POST /bitrix/cache/css/s3/tcell-en-new/template_886397fdef4213ff96297abf95f73de8/template_886397fdef4213ff96297abf95f73de8.css`

**Confidence**: 50%

---

### `POST /bitrix/cache/js/s2/tcell-tj-new/page_a81d73955a74dd2a2e3a8d2c8f27d42d/page_a81d73955a74dd2a2e3a8d2c8f27d42d.js`

**Confidence**: 50%

---

### `POST /bitrix/templates/tcell-en/tsr-fonts/icomoon_new.eot`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| ppeep3 | query | string |

---

### `POST /bitrix/templates/tcell-ru/tsr-fonts/icomoon_new.svg`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| ppeep3 | query | string |

---

### `POST /content/news/annual-package-2018/`

**Confidence**: 50%

---

### `POST /content/news/daily-mobile-from-tcell-is-back`

**Confidence**: 50%

---

### `POST /content/news/guess-the-tune-and-win-prizes-quiz-melomania/`

**Confidence**: 50%

---

### `POST /content/news/innovation-for-changes-in-tcell-start`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| PAGEN_1 | query | integer |

---

### `POST /content/news/it-conference-tajikistan-techconf-2016-`

**Confidence**: 50%

---

### `POST /content/news/pilot-project-on-development-of-open-educational-resources-has-been-successfully-completed/`

**Confidence**: 50%

---

### `POST /content/news/second-draw/`

**Confidence**: 50%

---

### `POST /content/news/tcell-4g-network/`

**Confidence**: 50%

---

### `POST /content/news/tcell-fft-tajikistan/`

**Confidence**: 50%

---

### `POST /content/news/tcell-is-instant-quiz-you-earn-/`

**Confidence**: 50%

---

### `POST /content/news/tcell-vstupil-v-sovet-po-iskusstvennomu-intellektu-/`

**Confidence**: 50%

---

### `POST /content/news/the-service-is-wise-thoughts-/`

**Confidence**: 50%

---

### `POST /content/news/the-winner-of-the-ticket-to-russia-for-58-day`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| PAGEN_1 | query | integer |

---

### `POST /content/news/ussd/`

**Confidence**: 50%

---

### `POST /en/content/news/daily-smartphone-campaign-draw-46/`

**Confidence**: 50%

---

### `POST /en/content/news/teznet-action/`

**Confidence**: 50%

---

### `POST /en/corporations/internet/options-and-services/new-internet-packages-g.php`

**Confidence**: 50%

---

### `POST /en/private-individuals/news/3116`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /public/userfiles/pic/News/preview_3topnew.jpg`

**Confidence**: 50%

---

### `POST /tj/content/news/alibi-idomi-cipta-awobajo-ba-rusia-50-rhoose/`

**Confidence**: 50%

---

### `POST /tj/content/news/ishtirokchilari-digitalcamptcell-do-afte-ast-ki-ba-mahtani-somono-thorat-maseland/`

**Confidence**: 50%

---

### `POST /tj/content/news/tcell-and-fmfb/`

**Confidence**: 50%

---

### `POST /api/NewsImage.aspx`

**Confidence**: 50%

---

### `POST /news/100633`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/102613`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/104343`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/106301`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/120660`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/122310`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/124167`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/125775`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/127350`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/128867`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/129989`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/131518`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/132944`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/134212`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/135268`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/136299`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/137189`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/138214`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/139169`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/139171`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/139842`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/140690`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/141527`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/142361`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/143338`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/204176`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/205203`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/205909`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/206684`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/207345`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/207855`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/208248`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/208662`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/209065`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/209348`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/209707`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/210035`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/210312`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/210738`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/211120`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/211526`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/211878`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/212280`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/212628`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/212957`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/213291`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/213639`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/213945`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/214236`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/214480`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/214778`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/215067`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/215371`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/215653`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/218337`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/218704`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/219117`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/219681`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/220006`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/220320`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/220748`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/220983`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/220989`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/221076`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/221563`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/222029`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/222874`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/223323`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/223866`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/224387`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/225085`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/226286`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/36934`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/41864`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/45882`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/49195`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/52320`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/57839`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/60995`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/67681`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/71830`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/75644`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/79415`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/81847`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/85139`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/88223`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/93893`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/96624`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/98742`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /click_check.php`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| action | query | string |

---

### `POST /ru/News/View/195`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| View_id | path | integer |

---

### `POST /tg/News/View/185`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| View_id | path | integer |

---

### `POST /news/103788`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

### `POST /news/36163`

**Confidence**: 50%

**Parameters**:

| Name | Location | Type |
|------|----------|------|
| news_id | path | integer |

---

