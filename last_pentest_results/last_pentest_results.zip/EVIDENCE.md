# Evidence Map

> Provenance and uncertainty documentation for https://tcell.tj

## Evidence Sources

| Source | Events | Types |
|--------|--------|-------|
| subfinder | 2 | dns_record |
| WAFDetector | 1 |  |
| whatweb | 1 | tech_detection |
| nmap | 1 | port_scan |
| CrawlerAgent | 1 | tool_timeout |
| gau | 231 | endpoint_discovered |
| SecurityHeaderAnalyzer | 3 |  |
| CommandInjectionAgent | 1 |  |
| SQLmapAgent | 1 |  |
| XSSValidatorAgent | 1 |  |
| ValidationHarness | 30 | validation_result |

## Claim Summary

| Type | Count | Avg Confidence |
|------|-------|----------------|
| waf_present | 1 | 60% |
| discovery_summary | 1 | 93% |
| missing_security_header | 7 | 67% |

## High Uncertainty Items

The following items have uncertainty > 50% and may require manual verification:

- **waf_present**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **discovery_summary**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0

- **missing_security_header**: https://tcell.tj
  - Uncertainty: 67%
  - Evidence refs: 0


---

## Why We Think This

Each claim in this analysis is derived from multiple evidence sources.
The confidence scores reflect the strength and consistency of the evidence.

**Legend**:
- **b (belief)**: Degree of belief the claim is true
- **d (disbelief)**: Degree of belief the claim is false
- **u (uncertainty)**: Degree of uncertainty
- **P**: Expected probability (b + a*u)

---

*Evidence collected by Shannon LSG v2*
